bl_info = {
    "name": "NiceTools Addon",
    "author": "Chebanenko Andrii",
    "version": (1, 0, 0),
    "blender": (4, 1, 0),
    "location": "View3D > NiceTools",
    "description": "Some hard surface automatization tools",
    "category": "Object",
}

import bpy
import os
import importlib

from . import operators
from . import ui_panel
importlib.reload(operators)
importlib.reload(ui_panel)

def register():
    operators.register()
    ui_panel.register()
    
def unregister():
    operators.unregister()
    ui_panel.unregister()

if __name__ == "__main__":
    register()
