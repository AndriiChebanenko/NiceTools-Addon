import bpy
from . import operators

class VIEW3D_PT_my_panel(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "NiceTools"
    bl_idname = "VIEW3D_PT_my_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'NiceTools'

    def draw(self, context):
        layout = self.layout
        layout.operator(operators.MoveOnZPlane.bl_idname)
        layout.operator(operators.CreateReferencesCollection.bl_idname)
        layout.operator(operators.HighpolyAndLowpoly.bl_idname)
        layout.operator(operators.ProcessLowpoly.bl_idname)
        
def register():
    bpy.utils.register_class(VIEW3D_PT_my_panel)

def unregister():
    bpy.utils.unregister_class(VIEW3D_PT_my_panel)
