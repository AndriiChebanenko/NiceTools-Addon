import bpy
import bmesh

class MoveOnZPlane(bpy.types.Operator):
    """Move mesh on z plane level"""
    bl_idname = "mesh.move_on_z_plane"
    bl_label = "To ground"
    offset: bpy.props.FloatProperty(name = "Offset", default=0.0)

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'

    def execute(self, context):
        # Отримуємо вибраний об'єкт мешу
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "None mesh is selected")
            return {'CANCELLED'}
        mesh = obj.data
        bm = bmesh.new()
        bm.from_mesh(mesh)
        # Знаходимо мінімальне значення координати z серед усіх вершин
        lowest_z_vertex = None
        lowest_z_value = float('inf')
        for vert in bm.verts:
            if vert.co.z < lowest_z_value:
                lowest_z_value = vert.co.z
                lowest_z_vertex = vert
        if lowest_z_vertex is None:
            self.report({'ERROR'}, "There is no vertice in mesh")
            bm.free()
            return {'CANCELLED'}
        bm.free()
        obj.location.z = self.offset - lowest_z_value
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

class CreateReferencesCollection(bpy.types.Operator):
    """Create collection \"References\" from selected"""
    bl_idname = "object.create_references_collection"
    bl_label = "Create References Collection"
    opasity: bpy.props.FloatProperty(name = "Opacity", default=1.0)

    @classmethod
    def poll(cls, context):
        return context.selected_objects

    def check_collection(self, context, collection_name):
        scene = context.scene
        for collection in scene.collection.children:
            if collection.name == collection_name:
                return collection
        return None

    def execute(self, context):
        selected_objects = context.selected_objects
        if selected_objects is None:
            self.report({'ERROR'}, "References are not selected")
            return {'CANCELLED'}
        for obj in selected_objects:
            if obj.type != 'EMPTY':
                self.report({'ERROR'}, "Only emptys must be selected")
                return {'CANCELLED'}
        references_collection = self.check_collection(bpy.context, "References")
        if references_collection is None:
            references_collection = bpy.data.collections.new("References")
            context.scene.collection.children.link(references_collection)
        for index, obj in enumerate(selected_objects):
            obj.name = f"ref_{index}"
            context.collection.objects.unlink(obj)
            references_collection.objects.link(obj)
            obj.show_empty_image_only_axis_aligned = True
            obj.use_empty_image_alpha = True
        return {'FINISHED'}

class HighpolyAndLowpoly(bpy.types.Operator):
    """Create Highpoly and Lowpoly collections from selected"""
    bl_idname = "object.highpoly_and_lowpoly"
    bl_label = "Highpoly and Lowpoly"
    
    @classmethod
    def poll(cls, context):
        return context.selected_objects

    def create_highpoly_collection(self, objects):
        original_collection = objects[0].users_collection[0]
        original_collection.name = "Highpoly"
        for obj in objects:
            obj.name = f"{obj.name}_high"

    def create_lowpoly_collection(self, context):
        if "Lowpoly" not in bpy.data.collections:
            lowpoly_collection = bpy.data.collections.new("Lowpoly")
            context.scene.collection.children.link(lowpoly_collection)
        else:
            lowpoly_collection = bpy.data.collections["Lowpoly"]
        return lowpoly_collection

    def execute(self, context):
        selected_objects = context.selected_objects
        if selected_objects is None:
            self.report({'ERROR'}, "No meshes selected")
            return {'CANCELLED'}
        for obj in selected_objects:
            if obj.type != 'MESH':
                self.report({'ERROR'}, "Only meshes must be selected")
                return {'CANCELLED'}
        self.create_highpoly_collection(selected_objects)
        lowpoly_collection = self.create_lowpoly_collection(context)        
        for obj in selected_objects:
            obj_copy = obj.copy()
            obj_copy.data = obj.data.copy()
            obj_copy.name = obj_copy.name.replace("_high.001", "_low")
            lowpoly_collection.objects.link(obj_copy)
        return {'FINISHED'}

class ProcessLowpoly(bpy.types.Operator):
    """Shade Flat, apply Mirror and remove other modifiers to objects in \"Lowpoly\" collection"""
    bl_idname = "object.process_lowpoly"
    bl_label = "Shade Flat, apply Mirror and remove other modifiers to objects in \"Lowpoly\" collection "
    
    @classmethod
    def poll(cls, context):
        return "Lowpoly" in bpy.data.collections

    def execute(self, context):
        lowpoly_collection = bpy.data.collections.get("Lowpoly")
        if lowpoly_collection is None:
            self.report({'ERROR'}, "Lowpoly collection not found")
            return {'CANCELLED'}
        for obj in lowpoly_collection.objects:
            if obj.type == 'MESH':
                bpy.context.view_layer.objects.active = obj
                bpy.ops.object.shade_flat()
                modifiers_copy = obj.modifiers[:]
                for mod in modifiers_copy:
                    if mod.type == 'MIRROR':
                        bpy.ops.object.modifier_apply(modifier=mod.name)
                    else:
                        bpy.ops.object.modifier_remove(modifier=mod.name)
        return {'FINISHED'}

def register():
    bpy.utils.register_class(MoveOnZPlane)
    bpy.utils.register_class(CreateReferencesCollection)
    bpy.utils.register_class(HighpolyAndLowpoly)
    bpy.utils.register_class(ProcessLowpoly)

def unregister():
    bpy.utils.unregister_class(MoveOnZPlane)
    bpy.utils.unregister_class(CreateReferencesCollection)
    bpy.utils.unregister_class(HighpolyAndLowpoly)
    bpy.utils.unregister_class(ProcessLowpoly)